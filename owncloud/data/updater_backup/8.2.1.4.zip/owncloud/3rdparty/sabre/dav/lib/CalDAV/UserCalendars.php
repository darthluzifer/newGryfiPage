<?php

namespace Sabre\CalDAV;

/**
 * This class is deprecated!
 *
 * It has been renamed to Sabre\CalDAV\CalendarHome.
 *
 * This stub class will be removed in a future version of sabredav.
 *
 * @deprecated
 * @copyright Copyright (C) 2007-2015 fruux GmbH (https://fruux.com/).
 * @author Evert Pot (http://evertpot.com/)
 * @license http://sabre.io/license/ Modified BSD License
 */
class UserCalendars extends CalendarHome {

}
