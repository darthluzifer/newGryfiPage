<?php

namespace Sabre\CalDAV;

/**
 * Deprecated! This class has been renamed to CalendarRoot.
 *
 * This stub class will be removed in a future version of sabredav!
 *
 * @deprecated
 * @copyright Copyright (C) 2007-2015 fruux GmbH (https://fruux.com/).
 * @author Evert Pot (http://evertpot.com/)
 * @license http://sabre.io/license/ Modified BSD License
 * @deprecated This class will be removed in a future version of sabredav.
 *   Use CalendarRoot instead of this class.
 */
class CalendarRootNode extends CalendarRoot {
}
