<?php

namespace Sabre\VObject;

use Sabre\VObject\Recur\EventIterator;

/**
 * RecurrenceIterator
 *
 * This class is deprecated. Use Sabre\VObject\Recur\EventIterator instead.
 * This class will be removed from a future version.
 *
 * @copyright Copyright (C) 2011-2015 fruux GmbH (https://fruux.com/).
 * @author Evert Pot (http://evertpot.com/)
 * @deprecated
 * @license http://sabre.io/license Modified BSD License
 */
class RecurrenceIterator extends EventIterator {


}
